export default function Home() {
  return (
    <main className="p-10 text-center">
      <h1 className="text-4xl font-bold text-green-600">🚀 Homepage Loaded!</h1>
    </main>
  );
}
